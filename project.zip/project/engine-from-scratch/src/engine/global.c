#include "global.h"
Global global = {0};